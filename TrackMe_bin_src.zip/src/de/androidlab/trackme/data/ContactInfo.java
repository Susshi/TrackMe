package de.androidlab.trackme.data;

import java.util.ArrayList;
import java.util.List;

import android.graphics.Bitmap;

public class ContactInfo {
    
    public Bitmap picture;
    public String name;
    public List<String> numbers = new ArrayList<String>();

}
